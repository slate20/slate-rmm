INSERT INTO users (username, email, password_hash, role) VALUES
('admin', 'admin@example.com', 'A13D2B3FED9D1EE5BC78017700BB7961CA853F7E53AFD54B8B83EC607D2BAE3D', 'administrator');
